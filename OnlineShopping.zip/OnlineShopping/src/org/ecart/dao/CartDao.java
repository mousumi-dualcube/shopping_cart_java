package org.ecart.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.ecart.db.DBConnector;
import org.ecart.vo.Product;
import org.ecart.vo.User;

public class CartDao {
	public int insertIntoCart(Product product, String emailId) throws SQLException {
		
		
		int i=0;
		if(isProductExist(product.getId()))
		{
			boolean isAlreadyExistInCart = isAlreadyExistInCart(emailId, product.getId());
			if(!isAlreadyExistInCart)
			{
				Connection con = null;
				con = DBConnector.getInstance().getConnection();
				
				PreparedStatement ps = con.prepareStatement("INSERT INTO CART VALUES(?,?,?,?,?,?)");
				
				ps.setLong(1, product.getId());
				ps.setString(2, product.getName());
				ps.setDouble(3, product.getPrice());
				ps.setInt(4, product.getQuantity());
				ps.setInt(5, 1); //Initially delivery status always be 1
				ps.setString(6, emailId); 
				
				i = ps.executeUpdate();
				if(i>0) {
					updateStock("INSERT_CART", product.getId());
					System.out.println("Successfully inserted into cart...");
				}
			}else 
			{
				i=2;
			}
		}else {
			i=3;
		}
		return i;
		
	}
	public List<Product> getProductsFromCart(String emailId) throws SQLException {
		Connection con = null;
		ResultSet rs = null;
		List<Product> productList = new ArrayList<>();
		try 
		{
			con = DBConnector.getInstance().getConnection();
			
			PreparedStatement ps = con.prepareStatement("SELECT * FROM CART WHERE UPPER(EMAIl_ID) = ?");
			ps.setString(1, emailId.toUpperCase().trim());
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Product product = new Product();
				
				product.setId(rs.getLong("PRODUCT_ID"));
				product.setName(rs.getString("PRODUCT_NAME"));
				product.setPrice(rs.getDouble("PRODUCT_PRICE"));
				product.setQuantity(rs.getInt("PRODUCT_QUANTITY"));
				
				productList.add(product);
			}
		}finally {
			
			if(rs != null) {
				rs.close();
			}
		}
		return productList;
	}
	
	public void removeFromCart(String emailId, long productId) throws SQLException {
		Connection con = null;
		int i=0;
		con = DBConnector.getInstance() .getConnection();
		
		PreparedStatement ps = con.prepareStatement("DELETE FROM CART WHERE UPPER(EMAIl_ID)=? AND PRODUCT_ID=?");
		ps.setString(1, emailId.toUpperCase().trim());
		ps.setLong(2, productId);
		
		i = ps.executeUpdate();
			
		if(i>0) {
			updateStock("DELETE_CART", productId);
			System.out.println("Successfully deleted from cart...");
		}
	}
	public void removeFromCart(String emailId) throws SQLException {
		Connection con = null;
		int i=0;
		con = DBConnector.getInstance() .getConnection();
		
		PreparedStatement ps = con.prepareStatement("DELETE FROM CART WHERE UPPER(EMAIl_ID)=?");
		ps.setString(1, emailId.toUpperCase().trim());
		
		ps.executeUpdate();
			
		
	}
	
	private void updateStock(String callFrom, long productId) throws SQLException 
	{
		Connection con = null;
		int i=0;
		con = DBConnector.getInstance().getConnection();
		int stockCount = getStockCount(productId);
		if("INSERT_CART".equals(callFrom)) {
			stockCount = stockCount - 1;
		}
		else if("DELETE_CART".equals(callFrom)) {
			stockCount = stockCount + 1;
		}
		
		PreparedStatement ps = con.prepareStatement("UPDATE PRODUCT SET STOCK=? WHERE PRODUCT_ID=?");
		
		ps.setInt(1, stockCount);
		ps.setLong(2, productId);
		
		i = ps.executeUpdate();
		if(i>0) {
			System.out.println("Stock updated successfully");
		}
			
	}
	
	private int getStockCount(long productId) throws SQLException 
	{
		Connection con = null;
		ResultSet rs= null;
		int stockCount = 0;
		con = DBConnector.getInstance().getConnection();
		PreparedStatement ps = con.prepareStatement("SELECT STOCK FROM PRODUCT WHERE PRODUCT_ID=?");
		ps.setLong(1, productId);
		rs = ps.executeQuery();
		if(rs.next()) {
			stockCount = rs.getInt("STOCK");
		}
		return stockCount;
	}
	private boolean isAlreadyExistInCart(String emailId,long productId) throws SQLException {
		Connection con = null;
		ResultSet rs = null;
		con = DBConnector.getInstance().getConnection();
		PreparedStatement ps = con.prepareStatement("SELECT * FROM CART WHERE PRODUCT_ID=? AND UPPER(EMAIL_ID)=?");
		ps.setLong(1, productId);
		ps.setString(2, emailId.toUpperCase().trim());
		rs = ps.executeQuery();
		if(rs.next()) {
			return true;
		}
		return false;
	}
	private boolean isProductExist(long productId) throws SQLException {
		Connection con = null;
		ResultSet rs = null;
		con = DBConnector.getInstance().getConnection();
		PreparedStatement ps = con.prepareStatement("SELECT * FROM PRODUCT WHERE PRODUCT_ID=?");
		ps.setLong(1, productId);
		rs = ps.executeQuery();
		if(rs.next()) {
			return true;
		}
		return false;
	}
	public String placeorder(String address, int pin, String landmark, User user) throws SQLException {
		Connection con = null;
		String orderId = getOrderid();
		String emailId = user.getEmailId();
		List<Product> productList = getProductsFromCart(emailId);
		con = DBConnector.getInstance().getConnection();
		upadateuserAddress(address, pin, landmark, user, con);
		Iterator<Product> itr = productList.iterator();
		while (itr.hasNext()) {
			Product product = (Product) itr.next();
			insertIntoOrder(product, address, pin, landmark, emailId, orderId, con);
		}
		removeFromCart(emailId);
		return orderId;
	}
	
	private void insertIntoOrder(Product product,String address, int pin, String landmark, String emailId, String orderId, Connection con) throws SQLException {
		
		String insertQuery = "INSERT INTO ORDERS VALUES(?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(insertQuery);
		
		ps.setString(1, orderId);
		ps.setString(2, emailId);
		ps.setLong(3, product.getId());
		ps.setString(4, product.getName());
		ps.setDate(5, new Date( new java.util.Date().getTime()));
		ps.setInt(6, org.ecart.util.Contants.YET_TO_DELIVER);
		ps.setString(7, address);
		ps.setInt(8, pin);
		ps.setString(9, landmark);
		ps.executeUpdate();
		
	}
	private String getOrderid() {
		UUID uniqueKey = UUID.randomUUID();   
		return uniqueKey.toString();
	}
	public void upadateuserAddress(String address, int pin, String landmark, User user, Connection con) throws SQLException {
		String updateSql = "UPDATE USERS SET ADDRESS=?, PIN=?, LANDMARK=? WHERE EMAIL_ID=?";
		PreparedStatement ps = con.prepareStatement(updateSql);
		
		ps.setString(1, address);
		ps.setInt(2, pin);
		ps.setString(3, landmark);
		ps.setString(4, user.getEmailId());
		
		ps.executeUpdate();
		
	}
	

}
