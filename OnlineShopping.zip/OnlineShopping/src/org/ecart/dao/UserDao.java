package org.ecart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.ecart.db.DBConnector;
import org.ecart.vo.User;

public class UserDao {
	public User getUserInfo(String emailId, String password) throws SQLException {
		
		ResultSet rs = null;
		String firstName;
		String lastName;
		long mobileNo=0;
		User user = null;
		Connection con = null;
		try 
		{
			con = DBConnector.getInstance() .getConnection();
			String selectQuery = "SELECT * FROM USERS WHERE lower(EMAIL_ID)=? AND USER_PASSWORD=?";
			PreparedStatement ps = con.prepareStatement(selectQuery);
			ps.setString(1, emailId.toLowerCase().trim());
			ps.setString(2, password);
			
			rs = ps.executeQuery();
			System.out.println("outside");
			if(rs.next()) {
				System.out.println("inside");
				user = new User();
				
				emailId = rs.getString("EMAIL_ID");
				firstName = rs.getString("FIRST_NAME");
				lastName = rs.getString("LAST_NAME");
				mobileNo = rs.getLong("MOBILE_NO");
				
				user.setEmailId(emailId);
				user.setFirstName(firstName);
				user.setLastName(lastName);
				user.setMobileNo(mobileNo);
			}
			
		}finally {
			if(rs != null) {
				rs.close();
			}
			if(con != null) {
				con.close();
			}
		}
		return user;
		
	}
	public int registerNewuser(User user, String password) throws SQLException {
		int i=0;
		if(!isUserExist(user.getEmailId()))
		{
				Connection con = null;
				con = DBConnector.getInstance().getConnection();
				String insertQuery = "INSERT INTO USERS(EMAIL_ID,FIRST_NAME,LAST_NAME,MOBILE_NO,USER_PASSWORD) VALUES(?,?,?,?,?)";
				
				PreparedStatement ps = con.prepareStatement(insertQuery);
				
				ps.setString(1, user.getEmailId());
				ps.setString(2, user.getFirstName());
				ps.setString(3, user.getLastName());
				ps.setLong(4, user.getMobileNo());
				ps.setString(5, password); 
				
				i = ps.executeUpdate();
		}else{
			i=0;
		}
		return i;
		
	}
	public boolean isUserExist(String emailId) throws SQLException {
		Connection con = null;
		ResultSet rs = null;
		con = DBConnector.getInstance().getConnection();
		String selectQuery = "SELECT * FROM USERS WHERE EMAIL_ID=?";
		PreparedStatement ps = con.prepareStatement(selectQuery);
		ps.setString(1, emailId);
		rs = ps.executeQuery();
		if(rs.next()) {
			return true;
		}
		return false;
	}
	public static void main(String[] args) throws SQLException {
		//System.out.println("SELECT * FROM USERS WHERE EMAIL_ID='"+"?"+"' AND USER_PASSWORD='?'");
		new UserDao().getUserInfo("sahebjana@ymail.com", "11111111");
	}
}
