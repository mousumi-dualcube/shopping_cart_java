package org.ecart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.ecart.db.DBConnector;
import org.ecart.vo.Product;

public class ProductDao {
	public List<Product> getAllProducts() throws SQLException {
		Connection con = null;
		ResultSet rs = null;
		List<Product> productList = new ArrayList<>();
		try 
		{
			con = DBConnector.getInstance().getConnection();
			
			PreparedStatement ps = con.prepareStatement("SELECT * FROM PRODUCT");
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Product product = new Product();
				
				product.setId(rs.getLong("PRODUCT_ID"));
				product.setName(rs.getString("PRODUCT_NAME"));
				product.setPrice(rs.getDouble("PRODUCT_PRICE"));
				product.setQuantity(1);
				
				productList.add(product);
			}
		}finally {
			
			if(rs != null) {
				rs.close();
			}
		}
		return productList;
	}
	public Product getSpecificProduct(long productId) throws SQLException {
		Connection con = null;
		ResultSet rs = null;
		Product product = new Product();
		try 
		{
			con = DBConnector.getInstance().getConnection();
			
			PreparedStatement ps = con.prepareStatement("SELECT * FROM PRODUCT WHERE PRODUCT_ID=?");
			ps.setLong(1, productId);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				product.setId(rs.getLong("PRODUCT_ID"));
				product.setName(rs.getString("PRODUCT_NAME"));
				product.setPrice(rs.getDouble("PRODUCT_PRICE"));
				product.setQuantity(1);
			}
		}finally {
			
			if(rs != null) {
				rs.close();
			}
		}
		return product;
	}
}
