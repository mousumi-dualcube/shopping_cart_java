package org.ecart.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.mail.MessagingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.ecart.dao.UserDao;
import org.ecart.util.WebUtil;
import org.ecart.vo.User;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try
		{
			String login = request.getParameter("login");
			String registration = request.getParameter("registration");
			String forgotPassword = request.getParameter("forgetPassword");
			if(login != null) {
				login(request, response);
			}
			if(registration !=null) {
				System.out.println("Registration!!!!");
				registerNewUser(request, response);
			}
			if(forgotPassword!=null) {
				forgotPassword(request, response);
			}
		
		}catch (Exception e) {
			throw new IOException("Database is down please try after sometime...",e);
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			RequestDispatcher rd = null;
			//String contextPath =  request.getContextPath();
			String emailId=request.getParameter("emailId");
			String password=request.getParameter("password");
			System.out.println(emailId);
			System.out.println(password);
			System.out.println("context path-->"+request.getContextPath());
			
			if(emailId != null && password != null) 
			{
				
				UserDao dao = new UserDao();
				User user = dao.getUserInfo(emailId, password);
				if(user != null) 
				{
					HttpSession session = request.getSession();
					session.setAttribute("LOGIN_USER_INFO", user);
					rd = getServletContext().getRequestDispatcher("/products.jsp");
					rd.forward(request, response);
					//response.sendRedirect(contectPath+"/products.jsp");
				}else 
				{
					request.setAttribute("LOGIN_FAILED", "Wrong Username or Password ");
					//response.sendRedirect(contectPath+"/login.jsp");
					rd = getServletContext().getRequestDispatcher("/login.jsp");
					rd.forward(request, response);
				}
			}else
			{
				request.setAttribute("LOGIN_FAILED", "Wrong Username or Password ");
				//response.sendRedirect(contectPath+"/login.jsp");
				rd = getServletContext().getRequestDispatcher("/login.jsp");
				rd.forward(request, response);
			}
		}catch (SQLException e) {
			throw new IOException("Database is down please try after sometime...",e);
		}
	}
	private void registerNewUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			RequestDispatcher rd = null;
			String name = request.getParameter("name");
			String surname = request.getParameter("surname");
			String emailId = request.getParameter("email");
			String  mobileNo = request.getParameter("phone");
			String password=request.getParameter("password");
			
			User user = new User();
			user.setFirstName(name);
			user.setLastName(surname);
			user.setEmailId(emailId);
			user.setMobileNo(new Long(mobileNo));
			
			UserDao dao = new UserDao();
			int i = dao.registerNewuser(user, password);
			if(i==1)
			{
				HttpSession session = request.getSession();
				session.setAttribute("LOGIN_USER_INFO", user);
				rd = getServletContext().getRequestDispatcher("/products.jsp");
				rd.forward(request, response);
			}else 
			{
				request.setAttribute("ALREADY_REGISTERED", "Alredy Registered.");
				rd = getServletContext().getRequestDispatcher("/register.jsp");
				rd.forward(request, response);
			}
			System.out.println(emailId);
			System.out.println(password);
			System.out.println("context path-->"+request.getContextPath());
			
			
		}catch (SQLException e) {
			throw new IOException("Database is down please try after sometime...",e);
		}
	}
	private void forgotPassword(HttpServletRequest request, HttpServletResponse response) throws MessagingException {
		try {
			String emailId = request.getParameter("emailId");
			if(emailId != null) {
				UserDao dao = new UserDao();
				boolean isuserExist = dao.isUserExist(emailId);
				if(isuserExist) {
					WebUtil.sendMail(emailId);
				}
			}
			
		}catch (SQLException e) {
			throw new MessagingException("Database is down please try after sometime...",e);
		}
	}

}
