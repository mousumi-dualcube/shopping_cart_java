package org.ecart.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.ecart.dao.CartDao;
import org.ecart.dao.ProductDao;
import org.ecart.vo.Product;
import org.ecart.vo.User;

public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CartServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try
		{
			RequestDispatcher rd = null;
			HttpSession session = request.getSession();
			User user= (User)session.getAttribute("LOGIN_USER_INFO");
			String emailId= user.getEmailId();
			String saveToCart = request.getParameter("saveToCart");
			String removeFromCart = request.getParameter("removeFromCart");
			String placeOrder = request.getParameter("placeOrder");
			
			if(saveToCart!=null) 
			{
				int i = insertIntoCart(request,emailId);
				rd = getServletContext().getRequestDispatcher("/products.jsp");
				if(i==1) 
				{
					request.setAttribute("INSERT_STATUS", "Successfully added to cart");
				}else if(i==2) {
					request.setAttribute("INSERT_STATUS", "Already added to cart.");
				}
				else if(i==3) {
					request.setAttribute("INSERT_STATUS", "Selected product is out of stock");
				}
				rd.forward(request, response);
			}
			if(removeFromCart !=null) {
				long producId = new Long(request.getParameter("productId"));
				removefromCart(emailId, producId);
				rd = getServletContext().getRequestDispatcher("/cart.jsp");
				request.setAttribute("DELETE_STATUS", "Successfully deleted from cart");
				rd.forward(request, response);
			}
			if(placeOrder !=null) {
				String orderId = placeOrder(request);
				request.setAttribute("ORDER_STATUS", "Order placed successfully. Order ID: "+orderId);
				rd = getServletContext().getRequestDispatcher("/cart.jsp");
				rd.forward(request, response);
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private int insertIntoCart(HttpServletRequest request, String emailId) throws SQLException {
		//String productName = request.getParameter("productName");
		long productId = new Long(request.getParameter("productId"));
		//double productPrice = new Double(request.getParameter("productPrice"));
		//int productQuantity = new Integer(request.getParameter("productQuantity"));
		
		System.out.println(productId);
		
		ProductDao productDao = new ProductDao();
		Product product = productDao.getSpecificProduct(productId);
		
		CartDao cartDao = new CartDao();
		int i = cartDao.insertIntoCart(product, emailId);
		return i;
			
	}

	private void removefromCart(String emailId,long producId) throws SQLException {
		CartDao cartDao = new CartDao();
		cartDao.removeFromCart(emailId, producId);
	}
	
	private String placeOrder(HttpServletRequest request) throws SQLException {
		String address = request.getParameter("address");
		int pin = new Integer(request.getParameter("pin"));
		String landmark = request.getParameter("landmark");
		HttpSession session = request.getSession();
		User user= (User)session.getAttribute("LOGIN_USER_INFO");
		
		CartDao dao = new CartDao();
		String orderId= dao.placeorder(address, pin, landmark, user);
		
		return orderId;
	}
}
