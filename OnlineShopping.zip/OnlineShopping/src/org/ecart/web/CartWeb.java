package org.ecart.web;

import java.sql.SQLException;
import java.util.List;

import org.ecart.dao.CartDao;
import org.ecart.vo.Product;

public class CartWeb {

	public List<Product> getProducts(String username) throws SQLException{
		CartDao cartDao = new CartDao();
		List<Product> productList = cartDao.getProductsFromCart(username);
		return productList;
	}
}
