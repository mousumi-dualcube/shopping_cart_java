package org.ecart.web;

import java.sql.SQLException;
import java.util.List;

import org.ecart.dao.ProductDao;
import org.ecart.vo.Product;

public class ProductWeb {
	public List<Product> getAllProducts() throws SQLException{
		ProductDao productDao = new ProductDao();
		List<Product> productList = productDao.getAllProducts();
		return productList;
	}
}
