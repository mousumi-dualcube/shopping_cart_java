package org.ecart.util;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.ecart.vo.User;

public class WebUtil {
	private static final String subject = "Current password";
	private static final String from = "sahebjana30@gmail.com";
	private static final String password = "sa!JA967480";
	private static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	/*public static void main(String[] args) throws Exception {
		//sendMail();
	}*/
	public static void sendMail(String emailId) throws MessagingException {
		String msg = "Hi,\n Your password is ";
		String to;
		try 
		{
			to = emailId;
			msg = msg ;
			System.out.println("Msg::"+msg);
			Properties props = new Properties();
			props.setProperty("mail.transport.protocol", "smtp");
			props.setProperty("mail.host", "smtp.gmail.com");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.port", "465");
			props.put("mail.debug", "true");
			props.put("mail.smtp.socketFactory.port", "465");
			props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			props.put("mail.smtp.socketFactory.fallback", "false");
			Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(from, password);
				}
			});

//			/Transport transport = session.getTransport();
			InternetAddress addressFrom = new InternetAddress(from);

			MimeMessage message = new MimeMessage(session);
			message.setSender(addressFrom);
			message.setSubject(subject);
			message.setContent(msg, "text/plain");
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			

			//transport.connect();
			//Transport.send(message);
			//transport.close();
			System.out.println("Mail successfully sent to "+to);

		} catch (MessagingException mex) {
			throw new MessagingException("Unable to send mail. ", mex);
		}
	}
	public static String randomAlphaNumeric(int count) 
	{
		StringBuilder builder = new StringBuilder();
		while (count <= count) {
			int character = (int)(Math.random()*ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}
	public static void main(String[] args) {
		System.out.println("");
		System.out.println(randomAlphaNumeric(6));
	}

}
