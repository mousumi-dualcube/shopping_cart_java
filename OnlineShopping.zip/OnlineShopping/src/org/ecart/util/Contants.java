package org.ecart.util;

public interface Contants {
	public int YET_TO_DELIVER = 1;
	public int DELIVERED = 2;
	public int CANCELLED = 3;
}
