package org.ecart.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnector {

    private static DBConnector dbIsntance;
    private static Connection con ;


    private DBConnector() { 
      // private constructor //
    }

    public static DBConnector getInstance(){
    if(dbIsntance==null){
        dbIsntance= new DBConnector();
    }
    return dbIsntance;
    }

    public  Connection getConnection() throws SQLException{

        if(con==null || con.isClosed()){
            try {
            	Class.forName("com.mysql.jdbc.Driver");
    			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/shopping_cart","root", "9477458322");
    			System.out.println("fdsgdy---"+con);
            } catch (SQLException | ClassNotFoundException ex) {
                System.out.println("Exception-->"+ex);
            }
        }

        return con;
    }
    public static void main(String[] args) throws SQLException {
    	System.out.println("in main");
		new DBConnector().getConnection();
	}
}
